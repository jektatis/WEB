# Portfolio de Jessica Guillesser — 3 pages GitHub Pages

Portfolio professionnel **statique, gratuit et responsive**, conçu pour la candidature à des postes **internes en DSI, gestion de projets ERP et transformation digitale**, pas pour présenter une activité de consultance indépendante.

## Contenu du projet

- `index.html` — **Accueil** : portrait néon, cartes 3D interactives, présentation et tableau de bord **illustratif** codé en HTML/CSS.
- `profil.html` — **Mon profil** : présentation, chronologie professionnelle, formation et langues.
- `expertises.html` — **Mes expertises** : six domaines d'intervention, études de cas sans données confidentielles, méthode et lien de contact.
- `styles.css` — palettes, mise en page, animation, glassmorphism, adaptations tablette / mobile.
- `script.js` — menu mobile, génération des cartes depuis `content.js`, animations légères.
- `content.js` — contenu professionnel **modifiable depuis un seul fichier** (chronologie, formations, langues, expertises et cas d'usage).
- `assets/hero-office.webp` — fond Accueil, issu de l'image fournie précédemment et sans textes.
- `assets/hero-glass.webp` — fond Mon profil, issu de l'image fournie précédemment et sans textes.
- `assets/hero-abstract.webp` — fond Mes expertises, issu de l'image fournie précédemment et sans textes.
- `assets/portrait-original.webp` — votre vraie photographie originale, adaptée au web.
- `favicon.svg` — icône JG.
- `SOURCES_ET_VERIFICATIONS.md` — sources et points à vérifier **avant de diffuser publiquement**.

Les textes, cartes, graphiques décoratifs, navigation et boutons sont **en HTML/CSS**, non intégrés aux images. Les chiffres fictifs des maquettes n'ont volontairement pas été repris.

## 1 — Prévisualiser immédiatement

Décompresser le ZIP, puis ouvrir `index.html` dans un navigateur (Chrome, Firefox ou Edge). Cliquer sur **Mon profil** et **Mes expertises** dans le menu. Les trois pages s'ouvrent localement sans serveur et sans npm.

Pour une prévisualisation plus proche de l'hébergement réel, démarrer un serveur local avec Python (facultatif) :

```bash
python -m http.server 8000
```

Ouvrir `http://localhost:8000`.

## 2 — Personnaliser

1. Ouvrir `content.js` dans VS Code ou un éditeur de texte.
2. Vérifier et modifier les intitulés, **dates historiques et diplômes** ; voir `SOURCES_ET_VERIFICATIONS.md`.
3. Modifier éventuellement le texte statique d'introduction dans chaque fichier HTML.
4. Les couleurs de référence sont en première ligne de `styles.css` : `--deep`, `--cyan`, `--blue`, `--violet` et `--pink`.
5. Les fonds peuvent être remplacés par des fichiers de même nom dans `assets/`, sans changer le code.
6. Les liens LinkedIn sont actuellement fonctionnels. Aucune adresse e-mail ni aucun CV PDF non fournis n'ont été inventés.

**Nom affiché : Jessica Guillesser**, conforme au profil LinkedIn communiqué. Modifier en un autre nom si nécessaire, dans les trois fichiers HTML et `content.js`.

## 3 — Publier gratuitement sur GitHub Pages

1. Se connecter à https://github.com/.
2. Créer un dépôt **public** nommé `VOTRE-IDENTIFIANT.github.io` (votre identifiant GitHub exact).
3. Dans ce dépôt, choisir **Add file → Upload files** puis envoyer les fichiers et sous-dossiers du ZIP **sans dossier parent supplémentaire**. Ne pas envoyer le ZIP lui-même.
4. Ouvrir **Settings → Pages**. Choisir **Deploy from a branch**, branche `main`, répertoire `/ (root)`. Enregistrer.
5. Visiter `https://VOTRE-IDENTIFIANT.github.io/`. Votre site peut prendre quelques minutes pour apparaître.

Pour un dépôt portant un autre nom, l'adresse habituelle est `https://VOTRE-IDENTIFIANT.github.io/NOM-DU-DEPOT/`. Les liens internes utilisent des **chemins relatifs** et restent compatibles.

## 4 — Ajouter votre CV plus tard

Aucun document PDF n'a été inventé. Lorsque vous aurez finalisé votre CV :

- Glisser votre PDF dans le dossier `assets/` sous le nom `CV-Jessica-Guillesser.pdf`.
- Ajouter une entrée HTML de ce type dans la barre de navigation ou dans la section de contact :

```html
<a href="assets/CV-Jessica-Guillesser.pdf" download>Télécharger mon CV</a>
```

## 5 — Sécurité et confidentialité

- Ne publiez aucune capture interne réelle d'IFS, SQL, indicateur chiffré ou nom de collègue sans l'accord de votre employeur.
- Les graphiques de la page d'accueil sont **purement conceptuels**, et non des résultats chiffrés réels.
- Votre photographie devient publique sur GitHub Pages ; ceci est normal pour un portfolio professionnel mais à prendre en compte.
- Les formulations de « domaines d'intervention » ne signifient pas que vous vendez des prestations : le site se positionne sur le **recrutement en entreprise**.
- Le profil LinkedIn public n'affiche pas toutes les données derrière sa connexion ; un export PDF LinkedIn serait nécessaire pour assurer une couverture exhaustive.

## 6 — Contrôles recommandés avant diffusion

- Vérifier la version ordinateur **et** mobile après publication.
- Faire confirmer les expériences historiques et les formations reprises de Viadeo.
- Vérifier les autorisations de mention de l'entreprise et l'absence d'informations confidentielles.
- Relire les textes en français pour adapter le ton à votre façon de vous présenter.
