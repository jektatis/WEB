# Sources & vérifications — à lire AVANT publication

## Profil LinkedIn public communiqué par Jessica
- https://fr.linkedin.com/in/jessicaguillesser
- Nom utilisé : Jessica Guillesser ; localisation : Toulouse et périphérie ; entreprise : GA Smart Building.
- Formation MyDigitalSchool Paris : période publique 2020–2021 ; compétences visibles en gestion de projet digital, Agile/Scrum, UX, HTML/CSS, Javascript et autres pratiques du web.
- Bénévolat : Cap Solidarité, mars–nov. 2016 ; jardin partagé en permaculture et site web.
- Langues telles qu'affichées publiquement : français et espagnol « bilingue ou langue natale », anglais « capacité professionnelle générale ».

**IMPORTANT** : l'accès non connecté à LinkedIn masque les intitulés détaillés / dates de plusieurs postes, la totalité du résumé et potentiellement d'autres diplômes et certifications. Ce portfolio ne prétend PAS couvrir l'intégralité du compte LinkedIn. Pour compléter intégralement, exporter son profil depuis LinkedIn au format PDF et mettre à jour `content.js`.

## Entreprise / fonction actuelle
- https://theorg.com/org/ga-smart-building/offices/toulouse — entrée publique « Jessica Guillesser — Chef de projet E-Learning ERP ».
- La description détaillée de missions ERP / IFS / lobby s'appuie également sur les projets expliqués par Jessica au cours de la création de ce portfolio. Aucun résultat chiffré ni aucune capture interne n'est publié.

## Source externe complémentaire — profil ancien
- https://viadeo.journaldunet.com/p/jessica-guillesser-3859207 — ancien profil au même nom : expérience USOAM (2017–2019), activité indépendante en communication digitale (2019–2020), cursus Université de La Salle (2009–2014), échanges Barcelone (2014) et Chili (2011–2012).
- Ces éléments ne sont pas intégralement vérifiables sur la version LinkedIn accessible sans connexion et doivent être **confirmés directement** avant de rendre votre site public. Ils restent modifiables ou supprimables en une minute dans `content.js`.

## À compléter volontairement
- Intitulés exacts et dates des autres expériences qui sont masqués par LinkedIn.
- Niveaux et intitulés académiques exacts (MyDigitalSchool, La Salle, échanges).
- Certifications supplémentaires ; liens publics vers des projets autorisés ; CV PDF officiel.
- Résultats qualitatifs ou chiffrés que vous êtes autorisée à divulguer.

## Choix éditoriaux
- **Candidature grands groupes / DSI** plutôt que conseil indépendant.
- 3 pages : Accueil, Mon profil, Mes expertises.
- « Services » est renommé « expertises / domaines d'intervention » pour éviter de suggérer des prestations freelance.
- Aucune statistique fictive, date d'entrée chez GA non confirmée, e-mail inventé ou appréciation non vérifiable.
- La présence d'un ancien profil public ne signifie pas que les dates ou intitulés y sont nécessairement à jour.
