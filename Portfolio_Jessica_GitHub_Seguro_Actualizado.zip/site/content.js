/*
  INFORMATIONS ÉDITABLES — Portfolio de Jessica Guillesser
  SOURCES: profil LinkedIn public + indications fournies dans la conversation;
  certaines expériences historiques proviennent de la fiche publique Viadeo.
  Vérifier les dates / intitulés avant publication : voir SOURCES_ET_VERIFICATIONS.md.
  AUCUN chiffre de performance inventé n'est affiché sur ce portfolio.
*/
window.PORTFOLIO = {
  name: 'Jessica Guillesser',
  linkedin: 'https://fr.linkedin.com/in/jessicaguillesser',
  experience: [
    {
      period: 'Aujourd’hui',
      role: 'Cheffe de projet E-learning ERP',
      company: 'GA Smart Building',
      category: 'ERP · DSI · Transformation',
      text: 'À l’interface des équipes métier et des systèmes d’information : coordination de dispositifs de formation ERP, contribution à l’adoption d’IFS Cloud, conception de lobbys métier et accompagnement des phases de validation et de déploiement.',
      tags: ['IFS Cloud','Gestion de projet','Lobbys & KPI','Accompagnement métier']
    },
    {
      period: '2019 – 2020',
      role: 'Projets de marketing & communication digitale',
      company: 'Activité indépendante',
      category: 'Communication · Digital',
      text: 'Stratégies et plans de communication, réalisation de contenus et supports digitaux. Une approche mêlant compréhension des besoins, création de supports et mise en œuvre.',
      tags: ['Stratégie digitale','Communication','Supports web']
    },
    {
      period: '2017 – 2019',
      role: 'Chargée de communication',
      company: 'USOAM',
      category: 'Communication · Web · Équipe',
      text: 'Coordination d’actions de communication, organisation d’événements et création de sites web pour l’association et ses sections sportives.',
      tags: ['Gestion d’équipe','Web','Communication']
    },
    {
      period: 'Mars – nov. 2016',
      role: 'Mission bénévole de développement social & solidaire',
      company: 'Cap Solidarité',
      category: 'Engagement · Projet',
      text: 'Participation à la création d’un jardin partagé en permaculture et à la réalisation d’un site web pour l’association.',
      tags: ['Projet solidaire','Création web']
    }
  ],
  education: [
    {
      icon:'⌘',year:'2020 – 2021',name:'MyDigitalSchool Paris',detail:'Formation en gestion de projet digital, méthode Agile & Scrum, UX Design et développement web.',chips:['Gestion de projet','Agile / Scrum','UX Design','HTML / CSS / JS']
    },
    {
      icon:'◇',year:'2009 – 2014',name:'Université de La Salle · Bogotá',detail:'Formation en gestion des entreprises.',chips:['Gestion','Économie','Vision internationale']
    },
    {
      icon:'↗',year:'Échanges universitaires',name:'Ramon Llull · Barcelone / Universidad Austral · Valdivia',detail:'Mobilités académiques internationales.',chips:['Espagne','Chili','Interculturalité']
    }
  ],
  languages: [
    ['Français','Bilingue ou langue natale · LinkedIn'],
    ['Espagnol','Bilingue ou langue natale · LinkedIn'],
    ['Anglais','Capacité professionnelle générale · LinkedIn']
  ],
  services: [
    { id:'erp', icon:'▥', index:'01', title:'Pilotage de projets ERP', summary:'Connecter les objectifs de transformation aux réalités opérationnelles.', points:['Coordination entre DSI et équipes métier','Recueil des besoins et structuration des livrables','Organisation des recettes et de la mise en production'],tags:['Projets ERP','IFS Cloud','Recette métier'] },
    { id:'kpi', icon:'⌁', index:'02', title:'Lobbys métier, reporting & KPI', summary:'Transformer les informations ERP en vues lisibles, contextualisées et exploitables.', points:['Conception d’interfaces de pilotage IFS Cloud','Filtres utilisateurs, indicateurs et requêtes SQL','Ateliers de validation avec les équipes métier'],tags:['IFS Lobbys','SQL','Tableaux de bord'] },
    { id:'formation', icon:'◇', index:'03', title:'E-learning & formation', summary:'Permettre aux utilisateurs de gagner en autonomie face à de nouveaux outils.', points:['Conception de parcours et contenus pédagogiques','Guides, tutoriels et supports utilisateurs','Organisation de formations et démonstrations'],tags:['Digital learning','Documentation','Pédagogie'] },
    { id:'change', icon:'◎', index:'04', title:'Conduite du changement', summary:'Faire de l’adoption un objectif de projet, pas une étape de dernière minute.', points:['Identification des usages et besoins du terrain','Communication autour des nouvelles fonctionnalités','Accompagnement avant et après le déploiement'],tags:['Adoption','Communication','Expérience utilisateur'] },
    { id:'digital', icon:'⌘', index:'05', title:'Gestion de projets digitaux', summary:'Un regard transversal issu d’un parcours en digital et communication.', points:['Planification et coordination de projets web','Conception fonctionnelle et expérience utilisateur','Animation des parties prenantes et suivi des livrables'],tags:['Gestion de projet','Digital','UX'] },
    { id:'bridge', icon:'✦', index:'06', title:'Interface métier & SI', summary:'Faciliter le dialogue entre besoins opérationnels et solutions techniques.', points:['Traduction des besoins en spécifications compréhensibles','Priorisation avec les utilisateurs et équipes SI','Documentation et amélioration continue'],tags:['Analyse fonctionnelle','Processus','Co-construction'] }
  ],
  cases: [
    { id:'case-1', category:'ERP · Reporting', number:'PROJET / 01', title:'Des lobbys IFS Cloud pensés pour les métiers', text:'Conception de vues de pilotage adaptées à différents profils (achats, commerce, projets), avec indicateurs, listes et filtres pertinents. Approche centrée sur les besoins, la recette et l’utilisation quotidienne.',tags:['IFS Cloud','SQL','UX métier'], visual:'visual-dashboard' },
    { id:'case-2', category:'ERP · Adoption', number:'PROJET / 02', title:'Accompagner une transformation ERP', text:'Contribution à la diffusion des usages et à l’accompagnement des équipes dans le cadre d’un programme de transformation ERP : supports, communication, formation et retours terrain.',tags:['Formation','Conduite du changement','Documentation'], visual:'visual-learning' },
    { id:'case-3', category:'Digital · Web', number:'PROJET / 03', title:'Créer des expériences digitales utiles', text:'Une expérience de gestion de projet digital, de conception d’interfaces et de communication qui enrichit aujourd’hui mon approche des outils professionnels.',tags:['Digital','Communication','UX Design'], visual:'visual-web' }
  ]
};
