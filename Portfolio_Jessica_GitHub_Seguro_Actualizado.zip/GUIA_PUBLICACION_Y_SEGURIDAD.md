# Jessica Guillesser — Portfolio preparado para GitHub Pages

Esta carpeta contiene el portfolio actualizado, la portada corregida y una revisión de seguridad preventiva. La carpeta **site/** es lo ÚNICO que debes publicar. Las capturas de **apercus/** son para revisar el diseño; la guía no necesita estar en la web.

## Qué cambia visualmente

- La fotografía de portada está reencuadrada y centrada visualmente hacia el centro-derecha.
- Los enlaces flotantes 3D están a la derecha en escritorio para no tapar el rostro.
- En teléfono las tarjetas quedan debajo del texto de presentación, con espacio adicional.
- Las tres páginas (Accueil, Mon profil, Mes expertises) siguen conectadas.

## Mejoras de seguridad aplicadas

1. Sitio 100 % estático: sin base de datos, cuentas de visitantes, formularios ni servidor propio.
2. **Content Security Policy** en las tres páginas: solo scripts, estilos e imágenes locales; bloquea conexiones de red desde scripts, marcos incrustados, objetos y envíos de formularios.
3. **Trusted Types** para los navegadores compatibles, como protección adicional contra determinadas inyecciones HTML.
4. El contenido que genera JavaScript se crea usando `createElement` y `textContent`, sin `innerHTML`, `eval` ni carga de código remoto.
5. Sin Google Fonts ni otras dependencias externas que se carguen al visitar la página. El único enlace externo intencional es LinkedIn y se abre con `noopener noreferrer`.
6. Política de referencia `no-referrer` para reducir la información transmitida al abrir sitios externos.
7. Solo archivos públicos necesarios dentro de `site/`: no se incluyen notas de verificación, CV privado, contraseñas, claves ni código de un servidor.

### Límites importantes

**No existe una garantía de que un sitio sea imposible de atacar.** Esta auditoría es estática y una revisión visual en un navegador con el HTML/CSS/JS integrados. No constituye una prueba de penetración ni reemplaza las medidas de seguridad de GitHub.

En particular, GitHub Pages determina las cabeceras HTTP de su alojamiento. Algunas protecciones, como `frame-ancestors` o `X-Frame-Options`, requieren cabeceras del servidor y **no pueden configurarse eficazmente con una etiqueta HTML**. La política CSP incluida protege fuentes de contenido, pero no equivale a todas las cabeceras HTTP posibles. La revisión visual del código no confirma el comportamiento de todas las políticas en la infraestructura final de GitHub Pages; compruébalo tras publicar.

Tu retrato, tu experiencia y todos los archivos del repositorio público podrán ser vistos por cualquiera. Evita publicar información confidencial de GA, consultas SQL internas, accesos o capturas sin autorización. Revisa en `content.js` las experiencias y fechas históricas antes de difundir la web.

## Publicar en GitHub Pages paso a paso

1. Accede a GitHub y **activa la autenticación en dos pasos**, idealmente una passkey o una llave física.
2. Crea un repositorio público llamado `TU-USUARIO.github.io`, sustituyendo TU-USUARIO por tu nombre exacto de GitHub.
3. Entra en `site/` dentro de este ZIP y sube **todos los archivos y la subcarpeta `assets/`** a la RAÍZ del repositorio. No subas la carpeta `site` como nivel extra ni los archivos `apercus/` o esta guía.
4. En el repositorio, abre `Settings > Pages` y selecciona `Deploy from a branch`, rama `main`, carpeta `/ (root)`; guarda.
5. Accede a `https://TU-USUARIO.github.io/`; activa **Enforce HTTPS** si la opción está disponible.
6. Comprueba las tres páginas y el menú en el móvil y en el ordenador.

Si utilizas un repositorio con otro nombre, la URL será `https://TU-USUARIO.github.io/NOMBRE-REPOSITORIO/` y los enlaces internos funcionarán al ser relativos.

### Vista previa local

Descomprime el ZIP, abre una terminal en `site/` y ejecuta:

```bash
python -m http.server 8000
```

Abre `http://localhost:8000`. Es una vista local; detener el comando cierra el servidor de prueba. Usa esa opción en vez de hacer doble clic en `index.html` si el navegador limita scripts locales.

### Modificar el contenido

- Experiencia, formación, idiomas, casos y habilidades: `site/content.js`.
- Textos principales y llamadas a la acción: `site/index.html`, `site/profil.html` y `site/expertises.html`.
- Colores, posición del retrato, animaciones: `site/styles.css`.
- Fotografías y fondos: `site/assets/`. No insertes en el sitio una clave API o una contraseña: todo el JavaScript del navegador es público.

### Comprobaciones realizadas

- Auditoría de archivos del paquete: 3 HTML, CSP y referrer policy, enlaces internos, recursos externos, atributos ejecutables, patrones JS peligrosos, recursos CSS y exclusión de documentos de trabajo. Sin errores en estas comprobaciones.
- Sintaxis de los dos archivos JavaScript: válida con Node.js.
- Capturas de las 3 páginas en pantalla de escritorio y móvil, con JavaScript ejecutado en un navegador usando recursos integrados para la revisión visual. Sin errores de ejecución JavaScript detectados en estas capturas.
- Verificar las cabeceras reales, fuentes y políticas CSP tras el despliegue, ya que el navegador de este entorno bloqueó las URL locales y no permitió la comprobación end-to-end con un servidor web local.
